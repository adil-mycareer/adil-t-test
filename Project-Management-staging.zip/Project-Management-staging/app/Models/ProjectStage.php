<?php

namespace App\Models;

use App\Traits\Filterable;
use App\Traits\HasFormOptions;
use App\Traits\LogsModelActivity;
use App\Traits\Sortable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class ProjectStage extends Model
{
    use SoftDeletes, Filterable, Sortable, LogsModelActivity, HasFormOptions;

    protected $fillable = [
        'name',
        'code',
        'color',
        'sort_order',
        'is_default',
        'is_system',
        'is_active'
    ];

    protected $sortable = [
        'name',
        'code',
        'sort_order',
    ];

    protected $searchable = ['name', 'code'];

    protected function casts(): array
    {
        return [
            'name' => 'string',
            'code' => 'string',
            'color' => 'string',
            'sort_order' => 'integer',
            'is_default' => 'boolean',
            'is_system' => 'boolean',
            'is_active' => 'boolean',
        ];
    }

    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }
}
