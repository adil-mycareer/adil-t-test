@extends('layouts.master')

@section('page-content')
    <main class="w-full px-6 pb-6 pt-[100px] sm:pt-[120px] xl:px-[48px] xl:pb-[48px]" data-activity-log-page>
        <div class="mb-6 flex flex-wrap items-center justify-between gap-3">
            <x-filters.button />

            @can('activity_log.delete')
                <div class="flex flex-wrap items-center justify-end gap-3 rounded-xl border border-bgray-200 bg-white px-4 py-3 shadow-sm dark:border-darkblack-400 dark:bg-darkblack-600">
                    <span id="selected-count" class="inline-flex h-11 items-center rounded-lg bg-bgray-100 px-4 text-sm font-medium text-bgray-700 dark:bg-darkblack-500 dark:text-bgray-300">
                        0 selected
                    </span>

                    <button type="button" id="bulk-delete-btn" data-bulk-delete-url="{{ route('activity.log.bulkDelete') }}"
                        class="inline-flex h-11 items-center justify-center gap-2 whitespace-nowrap rounded-lg border border-red-200 bg-red-50 px-5 text-sm font-semibold leading-none text-red-600 shadow-sm transition duration-200 hover:border-red-500 hover:bg-red-500 hover:text-white focus:outline-none focus:ring-2 focus:ring-red-200 disabled:cursor-not-allowed disabled:border-bgray-200 disabled:bg-bgray-100 disabled:text-bgray-400 disabled:shadow-none dark:border-red-900/40 dark:bg-darkblack-500 dark:text-red-400 dark:hover:border-red-500 dark:hover:bg-red-500 dark:hover:text-white dark:disabled:border-darkblack-400 dark:disabled:bg-darkblack-500 dark:disabled:text-bgray-500"
                        disabled>
                        <svg class="h-4 w-4 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                        </svg>
                        <span>Bulk Delete</span>
                    </button>
                </div>
            @endcan
        </div>

        @if (!empty($filteredProject))
            <div class="mb-6 flex flex-wrap items-center justify-between gap-3 rounded-xl border border-success-200 bg-success-50/70 px-4 py-3 shadow-sm dark:border-success-900/30 dark:bg-darkblack-600">
                <div>
                    <p class="text-sm font-semibold text-bgray-900 dark:text-white">
                        Showing activity for {{ $filteredProject->name }}
                    </p>
                    <p class="text-sm text-bgray-600 dark:text-bgray-300">
                        Includes this project and all related child records.
                    </p>
                </div>

                <a href="{{ route('activity.log') }}" class="inline-flex h-10 items-center justify-center rounded-lg border border-bgray-200 bg-white px-4 text-sm font-semibold text-bgray-700 transition hover:border-success-300 hover:text-success-400 dark:border-darkblack-400 dark:bg-darkblack-500 dark:text-bgray-100 dark:hover:border-success-300 dark:hover:text-success-300">
                    Clear Filter
                </a>
            </div>
        @elseif (!empty($filteredTask))
            <div class="mb-6 flex flex-wrap items-center justify-between gap-3 rounded-xl border border-success-200 bg-success-50/70 px-4 py-3 shadow-sm dark:border-success-900/30 dark:bg-darkblack-600">
                <div>
                    <p class="text-sm font-semibold text-bgray-900 dark:text-white">
                        Showing activity for task {{ $filteredTask->name }}
                    </p>
                    <p class="text-sm text-bgray-600 dark:text-bgray-300">
                        Includes this task and its related comments, notes, and time logs.
                    </p>
                </div>

                <a href="{{ route('activity.log') }}" class="inline-flex h-10 items-center justify-center rounded-lg border border-bgray-200 bg-white px-4 text-sm font-semibold text-bgray-700 transition hover:border-success-300 hover:text-success-400 dark:border-darkblack-400 dark:bg-darkblack-500 dark:text-bgray-100 dark:hover:border-success-300 dark:hover:text-success-300">
                    Clear Filter
                </a>
            </div>
        @endif

        <div class="2xl:flex 2xl:space-x-[48px]">
            <section class="mb-6 2xl:mb-0 2xl:flex-1">
                <div class="w-full rounded-lg bg-white px-[24px] py-[20px] dark:bg-darkblack-600">
                    <div class="flex flex-col space-y-5">
                        <div class="table-content w-full overflow-x-auto">
                            <table class="w-full">
                                <tr class="border-b border-bgray-300 dark:border-darkblack-400">
                                    <td>
                                        <span class="text-base font-medium text-bgray-600 dark:text-bgray-50">#</span>
                                    </td>
                                    @can('activity_log.delete')
                                        <td class="px-6 py-5 xl:px-0">
                                            <input type="checkbox" id="select-all" class="rounded border-gray-300 text-success-500 focus:ring-success-500">
                                        </td>
                                    @endcan
                                    <td class="px-6 py-5 xl:px-0">
                                        <div class="flex w-full items-center space-x-2.5">
                                            <x-sorting.sortable-column column="log_name" label="Module" />
                                        </div>
                                    </td>
                                    <td class="px-6 py-5 xl:px-0">
                                        <div class="flex w-full items-center space-x-2.5">
                                            <x-sorting.sortable-column column="event" label="Action" />
                                        </div>
                                    </td>
                                    <td class="px-6 py-5 xl:px-0">
                                        <div class="flex w-full items-center space-x-2.5">
                                            <span class="text-base font-medium text-bgray-600 dark:text-bgray-50">Record</span>
                                        </div>
                                    </td>
                                    <td class="px-6 py-5 xl:px-0">
                                        <div class="flex w-full items-center space-x-2.5">
                                            <span class="text-base font-medium text-bgray-600 dark:text-bgray-50">Changes</span>
                                        </div>
                                    </td>
                                    <td class="px-6 py-5 xl:px-0">
                                        <div class="flex w-full items-center space-x-2.5">
                                            <span class="text-base font-medium text-bgray-600 dark:text-bgray-50">By</span>
                                        </div>
                                    </td>
                                    <td class="px-6 py-5 xl:px-0">
                                        <div class="flex w-full items-center space-x-2.5">
                                            <x-sorting.sortable-column column="created_at" label="Logged At" />
                                        </div>
                                    </td>
                                    <td class="px-6 py-5 xl:px-0">
                                        <span class="text-base font-medium text-bgray-600 dark:text-bgray-50">Actions</span>
                                    </td>
                                </tr>

                                @php
                                    $startNumber = ($activities->currentPage() - 1) * $activities->perPage();
                                @endphp

                                @forelse ($activities as $activity)
                                    @php
                                        $subject = $activity->subject;
                                        $subjectLabel = $subject?->name ?? ($subject?->title ?? ($subject?->original_name ?? ($subject?->file_name ?? ($subject?->project_code ?? ($subject?->customer_code ?? ($subject?->employee_id ?? ($activity->subject_id ? '#' . $activity->subject_id : '--')))))));
                                        $subjectType = $activity->subject_type ? \Illuminate\Support\Str::headline(class_basename($activity->subject_type)) : '--';
                                        $ignoredFields = ['created_at', 'updated_at', 'deleted_at', 'added_by', 'updated_by'];
                                        $labels = collect($activity->getExtraProperty('labels', []));
                                        $changedFields = collect($activity->changes->get('attributes', []))
                                            ->keys()
                                            ->merge(collect($activity->changes->get('old', []))->keys())
                                            ->unique()
                                            ->reject(fn($field) => in_array($field, $ignoredFields, true))
                                            ->map(fn($field) => $labels->get($field, (string) \Illuminate\Support\Str::of($field)->replace('_id', '')->replace('_', ' ')->title()))
                                            ->values();
                                        $event = $activity->event ?? 'updated';
                                        $eventClasses = match ($event) {
                                            'created' => 'bg-success-50 text-success-400',
                                            'deleted' => 'bg-red-50 text-red-500',
                                            'restored' => 'bg-warning-50 text-warning-500',
                                            default => 'bg-blue-50 text-blue-500',
                                        };
                                        $currentModuleLabel = \Illuminate\Support\Str::headline($activity->log_name ?? 'default');
                                        $resolvedParentType = $activity->parent_type
                                            ? (\Illuminate\Database\Eloquent\Relations\Relation::getMorphedModel($activity->parent_type) ?? $activity->parent_type)
                                            : null;
                                        $parentModuleLabel = $resolvedParentType
                                            ? \Illuminate\Support\Str::headline(class_basename($resolvedParentType))
                                            : null;
                                        $milestoneLabel = $parentModuleLabel ?: $currentModuleLabel;
                                        $milestoneSubtitle = $parentModuleLabel && $parentModuleLabel !== $currentModuleLabel
                                            ? $currentModuleLabel
                                            : null;
                                        $changeSummary = match ($event) {
                                            'created' => $changedFields->isNotEmpty() ? 'Created ' . $changedFields->count() . ' ' . \Illuminate\Support\Str::plural('field', $changedFields->count()) . '.' : 'Created a new record.',
                                            'deleted' => $changedFields->isNotEmpty() ? 'Deleted record with ' . $changedFields->count() . ' tracked ' . \Illuminate\Support\Str::plural('field', $changedFields->count()) . '.' : 'Deleted a record.',
                                            'restored' => $changedFields->isNotEmpty() ? 'Restored ' . $changedFields->count() . ' ' . \Illuminate\Support\Str::plural('field', $changedFields->count()) . '.' : 'Restored a record.',
                                            default => $changedFields->isNotEmpty() ? 'Updated ' . $changedFields->count() . ' ' . \Illuminate\Support\Str::plural('field', $changedFields->count()) . '.' : 'Updated a record.',
                                        };
                                        $activityDescription = \Illuminate\Support\Str::headline(str_replace('.', ' ', $activity->description));
                                    @endphp

                                    <tr class="border-b border-bgray-300 dark:border-darkblack-400">
                                        <td class="px-6 py-5 xl:px-0">
                                            <span class="text-base font-medium text-bgray-600 dark:text-bgray-50">
                                                {{ $startNumber + $loop->iteration }}
                                            </span>
                                        </td>
                                        @can('activity_log.delete')
                                            <td class="px-6 py-5 xl:px-0">
                                                <input type="checkbox" class="activity-checkbox rounded border-gray-300 text-success-500 focus:ring-success-500" value="{{ $activity->id }}">
                                            </td>
                                        @endcan
                                        <td class="px-6 py-5 xl:px-0">
                                            <div class="flex flex-col rounded-md px-4 py-1.5">
                                                <span class="text-sm font-semibold leading-[22px] text-bgray-700 dark:text-bgray-50">
                                                    {{ $milestoneLabel }}
                                                </span>

                                                @if ($milestoneSubtitle)
                                                    <span class="mt-1 text-xs font-medium text-bgray-500 dark:text-bgray-300">
                                                        {{ $milestoneSubtitle }}
                                                    </span>
                                                @endif
                                            </div>
                                        </td>
                                        <td class="px-6 py-5 xl:px-0">
                                            <span class="inline-flex rounded-full px-3 py-1 text-xs font-semibold {{ $eventClasses }}">
                                                {{ \Illuminate\Support\Str::headline($event) }}
                                            </span>
                                        </td>
                                        <td class="px-6 py-5 xl:px-0">
                                            <div class="flex flex-col">
                                                <span class="text-base font-semibold text-bgray-900 dark:text-white">
                                                    {{ $subjectLabel }}
                                                </span>
                                                <span class="text-sm text-bgray-500 dark:text-bgray-300">
                                                    {{ $subjectType }}
                                                </span>
                                            </div>
                                        </td>
                                        <td class="px-6 py-5 xl:px-0">
                                            <div class="flex max-w-[280px] flex-col">
                                                <span class="text-sm text-bgray-500 dark:text-bgray-300">
                                                    {{ $changeSummary }}
                                                </span>

                                                @if ($changedFields->isNotEmpty())
                                                    <div class="mt-2 flex flex-wrap gap-1.5">
                                                        @foreach ($changedFields->take(3) as $label)
                                                            <span class="rounded-full bg-bgray-100 px-2.5 py-1 text-[11px] font-medium text-bgray-700 dark:bg-darkblack-500 dark:text-bgray-200">
                                                                {{ $label }}
                                                            </span>
                                                        @endforeach

                                                        @if ($changedFields->count() > 3)
                                                            <span class="rounded-full bg-bgray-100 px-2.5 py-1 text-[11px] font-medium text-bgray-700 dark:bg-darkblack-500 dark:text-bgray-200">
                                                                +{{ $changedFields->count() - 3 }} more
                                                            </span>
                                                        @endif
                                                    </div>
                                                @else
                                                    <span class="mt-1 text-sm font-medium text-bgray-700 dark:text-bgray-50">
                                                        {{ $activityDescription }}
                                                    </span>
                                                @endif
                                            </div>
                                        </td>
                                        <td class="px-6 py-5 xl:px-0">
                                            <div class="flex flex-col">
                                                <span class="text-sm font-semibold text-bgray-900 dark:text-white">
                                                    {{ $activity->causer?->name ?? 'System' }}
                                                </span>
                                                @if ($activity->causer?->email)
                                                    <span class="text-sm text-bgray-500 dark:text-bgray-300">
                                                        {{ $activity->causer->email }}
                                                    </span>
                                                @endif
                                            </div>
                                        </td>
                                        <td class="px-6 py-5 xl:px-0">
                                            <div class="flex flex-col">
                                                <span class="text-sm font-semibold text-bgray-900 dark:text-white">
                                                    {{ $activity->created_at?->timezone($globalTimezone)?->format($globalDateFormat) ?? '--' }}
                                                </span>
                                                <span class="text-sm text-bgray-500 dark:text-bgray-300">
                                                    {{ $activity->created_at?->timezone($globalTimezone)?->format($globalTimeFormat) ?? '--' }}
                                                </span>
                                            </div>
                                        </td>
                                        <td class="px-6 py-5 xl:px-0">
                                            <div class="flex items-center space-x-2">
                                                <x-activity-log.view-button :activity="$activity" />

                                                @can('activity_log.delete')
                                                    <x-delete-form :action="route('activity.log.destroy', $activity->id)" form-class="activity-log-delete-form" />
                                                @endcan
                                            </div>
                                        </td>
                                    </tr>
                                @empty
                                    <x-table-no-data :col-span="auth()->user()->can('activity_log.delete') ? 9 : 8" message="No activity logs found." />
                                @endforelse
                            </table>
                        </div>

                        <x-pagination :paginator="$activities" :per-page="$perPage" />
                    </div>
                </div>
            </section>
        </div>
    </main>

    <x-filters.drawer>
        @if (!empty($filteredProject))
            <input type="hidden" name="project_id" value="{{ $filteredProject->id }}">
        @elseif (!empty($filteredTask))
            <input type="hidden" name="task_id" value="{{ $filteredTask->id }}">
        @endif

        <x-filters.input-search name="search" label="Search" />
        <x-filters.multi-select name="log_name" label="Module" :options="$logNames" />
        <x-filters.select name="event" label="Action" :options="$eventOptions" />
        <x-filters.multi-select name="causer_id" label="User" :options="$causers" />

        <div class="flex flex-col gap-2">
            <label class="text-sm font-medium text-bgray-600 dark:text-bgray-50">From Date</label>
            <input type="date" name="date_from" value="{{ request('date_from') }}" class="w-full rounded-lg border border-gray-300 p-2 focus:border-success-300 focus:ring-0 bg-white text-gray-900 dark:bg-darkblack-500 dark:text-white dark:border-darkblack-400">
        </div>

        <div class="flex flex-col gap-2">
            <label class="text-sm font-medium text-bgray-600 dark:text-bgray-50">To Date</label>
            <input type="date" name="date_to" value="{{ request('date_to') }}" class="w-full rounded-lg border border-gray-300 p-2 focus:border-success-300 focus:ring-0 bg-white text-gray-900 dark:bg-darkblack-500 dark:text-white dark:border-darkblack-400">
        </div>
    </x-filters.drawer>
@endsection

@push('scripts')
    @vite('resources/js/modules/activity-logs.js')
@endpush
